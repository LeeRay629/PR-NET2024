import pandas as pd
import numpy as np
import scipy.stats as stats

mut_select = ['TP53', 'AR', 'PTEN', 'NUP98', 'OBSCN', 'MUC16', 'PSMD1', 'ABCA13', 'PPP2R5D', 'RB1', 'ATM', 'CREBBP', 'COL11A1','EP300','RANBP2','ROCK1','DCTN1','TP53BP1','NUP205','AGL']
cna_select = ['AR', 'PTEN', 'CUL1', 'PSMD2', 'RB1', 'PPP2R2A', 'PDGFA', 'PSAP', 'UBE2W', 'MDM2', 'ANAPC16', 'MDM4','PIK3CB','EIF3E','RAC1','COL1A2','FGFR1','MAP3K7','HIST1H2BD','HIST1H2AC','AP2A2','RRAGD','NEURL1B','NBN','HIST1H2AB','RPS27','GOLGA7','PSMD14','WWTR1']

def corr_gene(x_data, response_paper, conver_choice):

    colname_paper = x_data.iloc[0, :]
    x_data = x_data.drop(x_data.index[0])

    if conver_choice == True:
        x_data = x_data.astype('float')

    row, col = x_data.shape

    corr_pd = pd.DataFrame(columns=['spearman_value', 'p_value'], index=x_data.columns, data=np.zeros([col, 2]))

    loc = 0
    for i in x_data.columns:
        if stats.spearmanr(x_data[i], response_paper)[1] >= 0.05:
            corr_pd.iloc[loc, 0], corr_pd.iloc[loc, 1] = stats.spearmanr(x_data[i], response_paper)
        # print(x_paper.iloc[loc,1])
        loc += 1

    corr_positive = corr_pd.nlargest(50, 'spearman_value')
    corr_negative = corr_pd.nsmallest(50, 'spearman_value')
    corr_all = pd.concat([corr_positive, corr_negative], axis=0)


    # check_list = mut_select
    check_list = cna_select + mut_select

    regex_pattern = '|'.join(check_list)

    contains_pattern = corr_all.index.to_series().str.contains(regex_pattern)

    print("Indexes containing elements of list:")
    print(corr_all.index[contains_pattern])

    for element in check_list:
        # print(element)
        contains_element = corr_all.index.to_series().str.contains(element)
        if contains_element.any():
            print(f"Indexes containing '{element}':")
            print(corr_all.index[contains_element])

    return

# 1. prad_msk_stopsack_2021
# data2_x = pd.read_csv('..\\Dataset\\data2— prad_msk_stopsack_2021\\prad_msk_stopsack_2021_x.csv')
# data2_y = pd.read_csv('..\\Dataset\\data2— prad_msk_stopsack_2021\\prad_msk_stopsack_2021_y.csv')
# corr_gene(data2_x, data2_y, True)

# 2. prad_pik3r1_msk_2021
# data3_x = pd.read_csv('..\\Dataset\\data3 — prad_pik3r1_msk_2021\\prad_pik3r1_msk_2021_x.csv')
# data3_y = pd.read_csv('..\\Dataset\\data3 — prad_pik3r1_msk_2021\\prad_pik3r1_msk_2021_y.csv')
# corr_gene(data3_x, data3_y, True)

# 4. prad_cdk12_mskcc_2022
# data4_x = pd.read_csv('..\\Dataset\\data4 — prad_cdk12_mskcc_2020\\prad_cdk12_mskcc_2020_x.csv')
# data4_y = pd.read_csv('..\\Dataset\\data4 — prad_cdk12_mskcc_2020\\prad_cdk12_mskcc_2020_y.csv')
# corr_gene(data4_x, data4_y, True)

# 5. prad_mskcc_2017
data5_x = pd.read_csv('..\\Dataset\\data5 — prad_mskcc_2017\\prad_mskcc_2017_x.csv')
data5_y = pd.read_csv('..\\Dataset\\data5 — prad_mskcc_2017\\prad_mskcc_2017_y.csv')
corr_gene(data5_x, data5_y, True)

