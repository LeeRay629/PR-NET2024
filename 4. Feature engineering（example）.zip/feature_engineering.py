from data_access import Data

import numpy as np
import pandas as pd
from os.path import join, dirname, realpath

from sklearn.model_selection import train_test_split

# 1. data splits
response = pd.read_csv('prad_p1000_response.csv')

current_dir = dirname(realpath('processed'))
output_dir = 'splits'
output_dir = join(current_dir, output_dir)


all_ids = response
ids = response['id'].values
y = response['response'].values
#first split train and test
ids_train, ids_test, y_train, y_test = train_test_split(ids, y, test_size=0.1, stratify=y, random_state=42)
#then in train set, split train and validate

ids_train, ids_validate, y_train, y_validate = train_test_split(ids_train, y_train, test_size=len(y_test),
                                                                stratify=y_train, random_state=42)

test_set = pd.DataFrame({'id': ids_test, 'response': y_test})
train_set = pd.DataFrame({'id': ids_train, 'response': y_train})
validate_set = pd.DataFrame({'id': ids_validate, 'response': y_validate})

print(test_set.response.value_counts() / float(test_set.response.value_counts().sum()))
print(train_set.response.value_counts() / float(train_set.response.value_counts().sum()))
print(validate_set.response.value_counts() / float(validate_set.response.value_counts().sum()))

test_set.to_csv(join(output_dir, 'test_set.csv'))

validate_set.to_csv(join(output_dir, 'validation_set.csv'))
train_set.to_csv(join(output_dir, 'training_set.csv'))

total_number_samples = train_set.shape[0]
number_patients = np.geomspace(100, total_number_samples, 20)
number_patients = [int(s) for s in number_patients][::-1]
print(number_patients)

for i, n, in enumerate(number_patients):
    if i == 0:
        filename = join(output_dir, 'training_set_0.csv')
        train_set.to_csv(filename)
        continue
    number_samples = n
    print(i, number_samples)
    print(ids_train.shape, y_train.shape)
    ids_train, ids_validate, y_train, y_validate = train_test_split(ids_train, y_train, train_size=n,
                                                                    stratify=y_train, random_state=422342)
    print(ids_train.shape, y_train.shape)
    train_set = pd.DataFrame({'id': ids_train, 'response': y_train})
    filename = join(output_dir, 'training_set_{}.csv'.format(i))
    train_set.to_csv(filename)


# 2. feature_engineering
selected_genes = 'tcga_prostate_expressed_genes_and_cancer_genes.csv'

data = Data(id='ALL', type='prostate_paper', params={'data_type': ['mut_important', 'cnv_del', 'cnv_amp'], 'selected_genes': selected_genes})

x_train, x_test, y_train, y_test, info_train, info_test, columns = data.get_train_test()

x = np.concatenate((x_train, x_test))
np.savetxt('prad_p1000_x.csv', x, delimiter=',', fmt='%f')

y = np.concatenate((y_train, y_test))
np.savetxt('prad_p1000_y.csv', y, delimiter=',', fmt='%f')