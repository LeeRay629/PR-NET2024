import pandas as pd
import numpy as np
from sklearn.feature_selection import mutual_info_classif

def cal_mutual_info(x_paper, y_paper):

    mut_select = ['TP53', 'AR', 'PTEN', 'NUP98', 'OBSCN', 'MUC16', 'PSMD1', 'ABCA13', 'PPP2R5D', 'RB1', 'ATM', 'CREBBP',
                  'COL11A1', 'EP300', 'RANBP2', 'ROCK1', 'DCTN1', 'TP53BP1', 'NUP205', 'AGL']

    cna_select = ['AR', 'PTEN', 'CUL1', 'PSMD2', 'RB1', 'PPP2R2A', 'PDGFA', 'PSAP', 'UBE2W', 'MDM2', 'ANAPC16', 'MDM4',
                  'PIK3CB', 'EIF3E', 'RAC1', 'COL1A2', 'FGFR1', 'MAP3K7', 'HIST1H2BD', 'HIST1H2AC', 'AP2A2', 'RRAGD',
                  'NEURL1B', 'NBN', 'HIST1H2AB', 'RPS27', 'GOLGA7', 'PSMD14', 'WWTR1']

    all_select = mut_select + cna_select

    colname_paper = pd.DataFrame(columns=['gene'], data=list(x_paper.columns))
    x_paper = x_paper.drop(x_paper.index[0])
    y_paper = y_paper['response'].values.ravel()

    mutual_info_result = mutual_info_classif(x_paper, y_paper)

    indices = np.argpartition(mutual_info_result, -50)[-50:]

    top_50_values = mutual_info_result[indices]

    sorted_idx = np.argsort(-top_50_values)

    sorted_indices = indices[sorted_idx]
    sorted_top_50_values = top_50_values[sorted_idx]

    gene_mutual_info_high = colname_paper.loc[sorted_indices]
    gene_mutual_info_high['value'] = sorted_top_50_values

    regex_pattern = '|'.join(all_select)

    contains_pattern = gene_mutual_info_high['gene'].str.contains(regex_pattern)

    print("Indexes containing elements of list:")
    print(gene_mutual_info_high.loc[contains_pattern])

    return

# 1. prad_msk_stopsack_2021
data2_x = pd.read_csv('..\\Dataset\\data2— prad_msk_stopsack_2021\\prad_msk_stopsack_2021_x.csv')
data2_y = pd.read_csv('..\\Dataset\\data2— prad_msk_stopsack_2021\\prad_msk_stopsack_2021_y.csv')
cal_mutual_info(data2_x, data2_y)

# 2. prad_pik3r1_msk_2021
# data3_x = pd.read_csv('..\\Dataset\\data3 — prad_pik3r1_msk_2021\\prad_pik3r1_msk_2021_x.csv')
# data3_y = pd.read_csv('..\\Dataset\\data3 — prad_pik3r1_msk_2021\\prad_pik3r1_msk_2021_y.csv')
# cal_mutual_info(data3_x, data3_y)

# 3. prad_cdk12_mskcc_2022
# data4_x = pd.read_csv('..\\Dataset\\data4 — prad_cdk12_mskcc_2020\\prad_cdk12_mskcc_2020_x.csv')
# data4_y = pd.read_csv('..\\Dataset\\data4 — prad_cdk12_mskcc_2020\\prad_cdk12_mskcc_2020_y.csv')
# cal_mutual_info(data4_x, data4_y)

# 4. prad_mskcc_2017
# data5_x = pd.read_csv('..\\Dataset\\data5 — prad_mskcc_2017\\prad_mskcc_2017_x.csv')
# data5_y = pd.read_csv('..\\Dataset\\data5 — prad_mskcc_2017\\prad_mskcc_2017_y.csv')
# cal_mutual_info(data5_x, data5_y)



